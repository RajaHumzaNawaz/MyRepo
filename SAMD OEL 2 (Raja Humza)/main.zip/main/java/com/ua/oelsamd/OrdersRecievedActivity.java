package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class OrdersRecievedActivity extends AppCompatActivity {

    static ListView ProductsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders_recieved);
        ProductsList = (ListView) findViewById(R.id.productsRecievedList);
        loadList();
    }

    public void loadList(){
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, R.layout.activity_view_noninteraction_list, R.id.textViewNon, Products.productsOrdered);
        ProductsList.setAdapter(adapter);
    }
}