package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ProductsActivity extends AppCompatActivity {

    static ListView ProductsList;

    static TextView music;

    Intent SpecificProductActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);
        ProductsList = (ListView) findViewById(R.id.productsList);
        loadList();
        music = (TextView) findViewById(R.id.music);

        this.SpecificProductActivity = new Intent(this, SpecificProductActivity.class);
    }

    public void loadList(){
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, R.layout.activity_view_list, R.id.textView, Products.productsNameArray);
        ProductsList.setAdapter(adapter);
    }

    public void ViewProduct(View view) {
        TextView nameTXT = (TextView) view;
        String name = nameTXT.getText().toString();

        if(name.equals("Music")){
            if (isMyServiceRunning(service.class)) {
                music.setText("");
                stopService(new Intent(this, service.class));
            } else {
                music.setText("Press to Stop Music");
                startService(new Intent(this, service.class));
            }
        }
        else{
            SpecificProductActivity.putExtra("productname", name);
            startActivity(this.SpecificProductActivity);
        }


    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void stopMusic(View view) {
        if (isMyServiceRunning(service.class)) {
            music.setText("");
            stopService(new Intent(this, service.class));
        }
    }


}