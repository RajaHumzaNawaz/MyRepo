package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CheckoutActivity extends AppCompatActivity {

    TextView name;
    TextView price;
    String u;
    int productprice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        name = findViewById(R.id.checkoutName);
        price = findViewById(R.id.checkoutPrice);
        u = (String) getIntent().getStringExtra("productname");
        productprice = (int) getIntent().getIntExtra("productprice",0);

        name.setText(name.getText()+""+u);
        price.setText(price.getText()+""+productprice);
    }

    public void onConfirmCheckOut(View view) {
        Products.addProductSale(u);

        Toast.makeText(getApplicationContext(),"Checkout Successful",Toast.LENGTH_SHORT).show();

    }
}