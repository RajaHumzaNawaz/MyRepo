package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ViewListActivity extends AppCompatActivity {

    Intent SpecificProductActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);
        this.SpecificProductActivity = new Intent(this, SpecificProductActivity.class);
    }

    public void ViewProduct(View view) {
        TextView nameTXT = (TextView) view;
        String name = nameTXT.getText().toString();

        SpecificProductActivity.putExtra("productname", name);
        startActivity(this.SpecificProductActivity);

    }
}