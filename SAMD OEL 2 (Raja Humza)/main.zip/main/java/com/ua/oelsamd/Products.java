package com.ua.oelsamd;

public class Products {
    public static Product products[] = {new Product("Alpha","Rifle with many things",120),new Product("Music","Music",1)};
    public static String productsNameArray[] = {"Alpha","Music"};
    public static String productsOrdered[] = new String[0];

    public static void addProduct(String productName, String productDescription, int price){

        int newlength = products.length + 1;
        Product newProducts[] = new Product[newlength];
        String newProductsName[] = new String[newlength];
        for (int i=0; i<newlength;i++){
            if(i==newlength-1){
                newProducts[i]= new Product(productName,productDescription,price);
                newProductsName[i]= productName;
            }
            else{
                newProducts[i]=products[i];
                newProductsName[i]= productsNameArray[i];
            }
        }
        products =newProducts;
        productsNameArray =newProductsName;
    }

    public static void addProductSale(String productName){

        int newlength = productsOrdered.length + 1;
        String newProductsName[] = new String[newlength];
        for (int i=0; i<newlength;i++){
            if(i==newlength-1){
                newProductsName[i]= productName;
            }
            else{
                newProductsName[i]= productsOrdered[i];
            }
        }
        productsOrdered =newProductsName;
    }
}


class Product {
    String productName;
    String productDescription;
    int price;
    String status;

    Product(String productName, String productDescription, int price){
        this.productName=productName;
        this.productDescription=productDescription;
        this.price=price;
        this.status="PENDING";
    }

    public void changeStatus(){
        this.status="Approved";
    }

}