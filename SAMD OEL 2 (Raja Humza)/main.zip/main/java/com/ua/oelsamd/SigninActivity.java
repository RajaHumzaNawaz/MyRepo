package com.ua.oelsamd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SigninActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Intent ProfileActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        username = findViewById(R.id.loginUserTxt);
        password = findViewById(R.id.loginPassTxt);
        this.ProfileActivity = new Intent(this, ProfileActivity.class);
    }

    public void onLogin(View view) {
        if(username.getText().toString().equals("")  || password.getText().toString().equals("") ){
            Toast.makeText(getApplicationContext(),"Fill your Credentials first !!!",Toast.LENGTH_SHORT).show();
            return;
        }
        User u = Users.login(username.getText().toString(),  password.getText().toString());
        if (u == null) {Toast.makeText(getApplicationContext(),"Invaid Credentials !!!",Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(getApplicationContext(),"Login Successful !!!",Toast.LENGTH_SHORT).show();
        ProfileActivity.putExtra("user",u);
        startActivity(this.ProfileActivity);
    }
}