package com.ua.oelsamd;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class ProfileActivity extends AppCompatActivity  {
    TextView name;
    TextView username;
    TextView age;
    static ImageView pic;
    Intent OrdersRecievedActivity;
    Intent OrdersDoneActivity;
    Intent ProductsActivity;
    static User u;
    static String a="null";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        this.OrdersRecievedActivity = new Intent(this, OrdersRecievedActivity.class);
        this.OrdersDoneActivity = new Intent(this, OrdersDoneActivity.class);
        this.ProductsActivity = new Intent(this, ProductsActivity.class);
        username = findViewById(R.id.profileUserNameTxt);
        name = findViewById(R.id.profileUserTxt);
        age = findViewById(R.id.profileAgeTxt);
        pic = findViewById(R.id.profilePic);
        u = (User) getIntent().getSerializableExtra("user");
        username.setText(username.getText()+u.username);
        name.setText(name.getText()+u.name);
        age.setText(age.getText()+u.age);
    }

    public void onNewProduct(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Product");
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams params = new  LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.leftMargin= 50;
        params.rightMargin= 50;
        params.topMargin = 50;
        params.bottomMargin = 50;

        EditText nameinput = new EditText(this);
        nameinput.setInputType(InputType.TYPE_CLASS_TEXT);
        nameinput.setHint("Product Name");
        nameinput.setLayoutParams(params);
        linearLayout.addView(nameinput);

        EditText descriptioninput = new EditText(this);
        descriptioninput.setInputType(InputType.TYPE_CLASS_TEXT);
        descriptioninput.setHint("Product Description");
        descriptioninput.setLayoutParams(params);
        linearLayout.addView(descriptioninput);

        EditText priceinput = new EditText(this);
        priceinput.setInputType(InputType.TYPE_CLASS_NUMBER);
        priceinput.setHint("Product Price");
        priceinput.setLayoutParams(params);
        linearLayout.addView(priceinput);




        builder.setView(linearLayout);


        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Products.addProduct(nameinput.getText().toString(),descriptioninput.getText().toString(), Integer.parseInt(priceinput.getText().toString()));
                        Toast.makeText(getApplicationContext(),"Product Added",Toast.LENGTH_SHORT).show();

                    }
                }
        );
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();

    }


    public void onBtnProducts(View view) {
        startActivity(this.ProductsActivity);
    }

    public void onBtnRecieved(View view) {
        startActivity(this.OrdersRecievedActivity);
    }


    public void onBtnDone(View view) {
        startActivity(this.OrdersDoneActivity);
    }
}