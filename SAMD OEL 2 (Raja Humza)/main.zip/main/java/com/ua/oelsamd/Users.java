package com.ua.oelsamd;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Users {
    public static List<User> users = new ArrayList<User>();

    public static boolean garageOpen = false;

    public static void initializeUsers(){
        addUsers("alpha","Alpha", "abc", "https://www.logolynx.com/images/logolynx/8b/8bac15590417ece600984c760ed1fe96.jpeg","20");
        addUsers("bravo","Bravo", "abc", "https://www.logolynx.com/images/logolynx/8b/8bac15590417ece600984c760ed1fe96.jpeg","20");
        addUsers("charlie","Charlie", "abc", "https://www.logolynx.com/images/logolynx/8b/8bac15590417ece600984c760ed1fe96.jpeg","20");
    }

    public static void addUsers(String name, String username, String password, String profileUri, String age){
        User u = new User(name,username,password,profileUri,age);
        users.add(u);
    }

    public static User login(String username, String password){
        for (User u: users) {
            if(u.username.equals(username) && u.password.equals(password)){
                return u;
            }
        }
        return null;
    }
}

class User implements Serializable {
    String name;
    String username;
    String password;
    String profileUri;
    String age;

    User(String name, String username, String password, String profileUri, String age){
        this.name = name;
        this.username = username;
        this.password = password;
        this.profileUri = profileUri;
        this.age = age;
    }
    User(){
        this.name = "";
        this.username = "";
        this.password = "";
        this.profileUri = "";
        this.age = "";
    }
}
