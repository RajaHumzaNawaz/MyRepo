package com.ua.oelsamd;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText name;
    EditText username;
    EditText age;
    EditText profileUri;
    EditText password;
    EditText confirmpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name = findViewById(R.id.registerNameTxt);
        username = findViewById(R.id.registerUserTxt);
        age = findViewById(R.id.registerAgeTxt);
        profileUri = findViewById(R.id.registerProfileTxt);
        password = findViewById(R.id.registerPassTxt);
        confirmpassword = findViewById(R.id.registerConPassTxt);
    }

    public void onRegister(View view) {
        if(name.getText().toString().equals("") || username.getText().toString().equals("")  || age.getText().toString().equals("")  || profileUri.getText().toString().equals("")  || password.getText().toString().equals("")  || confirmpassword.getText().toString().equals("") ) {
            Toast.makeText(getApplicationContext(),"Fill the data first !!!",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!(password.getText().toString().equals(confirmpassword.getText().toString()))){
            Toast.makeText(getApplicationContext(),"Password is not same at Confirm Password !!!",Toast.LENGTH_SHORT).show();
            return;
        }
        Users.addUsers(name.getText().toString(),username.getText().toString(),password.getText().toString(),profileUri.getText().toString(),age.getText().toString());
        Toast.makeText(getApplicationContext(),"User Registered, Go Back to Login !!!",Toast.LENGTH_SHORT).show();
    }
}