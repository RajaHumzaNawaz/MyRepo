package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SpecificProductActivity extends AppCompatActivity {

    TextView name;
    TextView description;
    TextView price;
    String u;
    Intent CheckoutActivity;
    String productname;
    int productPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific_product);

        this.CheckoutActivity = new Intent(this, CheckoutActivity.class);
        name = findViewById(R.id.productName);
        description = findViewById(R.id.productDesc);
        price = findViewById(R.id.productPrice);
        u = (String) getIntent().getStringExtra("productname");

        for(int i=0; i < Products.products.length; i++){
            if(Products.products[i].productName.equals(u)){
                name.setText(name.getText()+Products.products[i].productName);
                description.setText(description.getText()+Products.products[i].productDescription);
                price.setText(price.getText()+""+Products.products[i].price);
                productname = Products.products[i].productName;
                productPrice = Products.products[i].price;
            }
        }

    }

    public void onCheckOut(View view) {

        CheckoutActivity.putExtra("productname", productname);
        CheckoutActivity.putExtra("productprice", productPrice);
        startActivity(this.CheckoutActivity);

    }
}