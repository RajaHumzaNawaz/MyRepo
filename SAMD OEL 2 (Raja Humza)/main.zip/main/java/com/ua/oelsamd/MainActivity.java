package com.ua.oelsamd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    Intent LoginActivity;
    Intent RegisterActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Users.initializeUsers();
        this.LoginActivity = new Intent(this, SigninActivity.class);
        this.RegisterActivity = new Intent(this, RegisterActivity.class);

    }

    public void onBtnLogin(View paramView) { startActivity(this.LoginActivity); }

    public void onBtnRegister(View paramView) { startActivity(this.RegisterActivity); }
}